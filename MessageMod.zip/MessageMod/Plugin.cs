﻿using System;
using System.Collections;
using System.Net;
using BepInEx;
using GorillaNetworking;
using OculusSampleFramework;
using Photon.Pun;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Tilemaps;
using UnityEngine.XR;
using Utilla;

namespace MessageMod
{
    /// <summary>
    /// This is your mod's main class.
    /// </summary>

    /* This attribute tells Utilla to look for [ModdedGameJoin] and [ModdedGameLeave] */
    [ModdedGamemode]
    [BepInDependency("org.legoandmars.gorillatag.utilla", "1.5.0")]
    [BepInPlugin(PluginInfo.GUID, PluginInfo.Name, PluginInfo.Version)]
    public class Plugin : BaseUnityPlugin
    {
        private int id;
        private Rect SIZE = new Rect(10f, 10f, 300f, 100f);
        private bool GitHubUI;
        public bool spam;
        public string Message = "";
        public string PutYourGithub = "https://raw.githubusercontent.com/hellohellohelloCsharp/MessageMod/main/Message";
        private static Texture2D button = new Texture2D(1, 1);
        private static Texture2D buttonhovered = new Texture2D(1, 1);
        private static Texture2D buttonactive = new Texture2D(1, 1);
        private static Texture2D windowbackground = new Texture2D(1, 1);
        private static Texture2D textarea = new Texture2D(1, 1);
        private static Texture2D textareahovered = new Texture2D(1, 1);
        private static Texture2D textareaactive = new Texture2D(1, 1);

        // scroll view
        private static Texture2D scrollview = new Texture2D(1, 1);
        private static Texture2D scrollviewhovered = new Texture2D(1, 1);
        private static Texture2D scrollviewactive = new Texture2D(1, 1);
        public void gui(int id)
        {
            Updatestuff();
            Init();

            GUI.color = UnityEngine.Color.red;
            PutYourGithub = GUI.TextArea(new Rect(10f, 50f, 160f, 20f), PutYourGithub.ToUpper());


            GUI.DragWindow();
        }

        private void OnGUI()
        {
            if (GitHubUI)
            {
                GUI.backgroundColor = new UnityEngine.Color(0f, 0f, 99f, 0.7f);
                GUI.contentColor = new UnityEngine.Color(0f, 99f, 0.7f);
                SIZE = GUI.Window(id, SIZE, new GUI.WindowFunction(gui), $"<color=cyan>PUT YOUR GITHUB LINK HERE:</color>");
            }
        }

        void fixedUpdate()
        {
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/debugtext").SetActive(true);
        }
        void Update()
        {
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/debugtext").SetActive(true);
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/debugtext/debugtext").GetComponent<UnityEngine.UI.Text>().text = Message;
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/debugtext").GetComponent<UnityEngine.UI.Text>().text = "Message:";
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/debugtext").transform.localPosition = new Vector3(-28.4553f, 26.4324f, 0.5617f);
            if (Keyboard.current.rightShiftKey.wasPressedThisFrame)
            {
                GitHubUI = !GitHubUI;
            }
        }
        private void GetGitHubContent()
        {
            using (WebClient client = new WebClient())
            {
                try
                {
                    Message = client.DownloadString(PutYourGithub);
                }
                catch (WebException ex)
                {
                    Debug.LogError("Error downloading content: " + ex.Message);
                }
            }
        }
        public IEnumerator RefreshMessage()
        {
            spam = true;
            while (spam)
            {
                GetGitHubContent();
                yield return new WaitForSeconds(5f);
            }
        }

        void Start()
        {
            /* A lot of Gorilla Tag systems will not be set up when start is called /*
			/* Put code in OnGameInitialized to avoid null references */

            Utilla.Events.GameInitialized += OnGameInitialized;
        }

        void OnEnable()
        {
            /* Set up your mod here */
            /* Code here runs at the start and whenever your mod is enabled*/

            HarmonyPatches.ApplyHarmonyPatches();
        }

        void OnDisable()
        {
            /* Undo mod setup here */
            /* This provides support for toggling mods with ComputerInterface, please implement it :) */
            /* Code here runs whenever your mod is disabled (including if it disabled on startup)*/

            HarmonyPatches.RemoveHarmonyPatches();
        }

        void OnGameInitialized(object sender, EventArgs e)
        {
            base.StartCoroutine(RefreshMessage());
        }
        public static void Updatestuff()
        {
            // button
            GUI.skin.button.onNormal.background = button;
            GUI.skin.button.onHover.background = buttonhovered;
            GUI.skin.button.onActive.background = buttonactive;
            GUI.skin.button.normal.background = button;
            GUI.skin.button.hover.background = buttonhovered;
            GUI.skin.button.active.background = buttonactive;
            // window
            GUI.skin.window.onNormal.background = windowbackground;
            GUI.skin.window.onHover.background = windowbackground;
            GUI.skin.window.onActive.background = windowbackground;
            GUI.skin.window.onNormal.textColor = Color.white;
            GUI.skin.window.onHover.textColor = Color.white;
            GUI.skin.window.onActive.textColor = Color.white;
            GUI.skin.window.normal.background = windowbackground;
            GUI.skin.window.hover.background = windowbackground;
            GUI.skin.window.active.background = windowbackground;
            GUI.skin.window.normal.textColor = Color.white;
            GUI.skin.window.hover.textColor = Color.white;
            GUI.skin.window.active.textColor = Color.white;
            // text field & text area
            GUI.skin.textArea.onNormal.background = textarea;
            GUI.skin.textArea.onHover.background = textareahovered;
            GUI.skin.textArea.onActive.background = textareaactive;
            GUI.skin.textField.onNormal.background = textarea;
            GUI.skin.textField.onHover.background = textareahovered;
            GUI.skin.textField.onActive.background = textareaactive;
            GUI.skin.textField.onFocused.background = textareaactive;
            GUI.skin.textArea.normal.background = textarea;
            GUI.skin.textArea.hover.background = textareahovered;
            GUI.skin.textArea.active.background = textareaactive;
            GUI.skin.textField.normal.background = textarea;
            GUI.skin.textField.hover.background = textareahovered;
            GUI.skin.textField.active.background = textareaactive;
            GUI.skin.textField.focused.background = textareaactive;
            // box
            GUI.skin.box.onNormal.background = box;
            GUI.skin.box.onHover.background = box;
            GUI.skin.box.onActive.background = box;
            GUI.skin.box.onNormal.textColor = Color.white;
            GUI.skin.box.onHover.textColor = Color.white;
            GUI.skin.box.onActive.textColor = Color.white;
            GUI.skin.box.normal.background = box;
            GUI.skin.box.hover.background = box;
            GUI.skin.box.active.background = box;
            GUI.skin.box.normal.textColor = Color.white;
            GUI.skin.box.hover.textColor = Color.white;
            GUI.skin.box.active.textColor = Color.white;
            // scroll bar
            GUI.skin.scrollView.onNormal.background = scrollview;
            GUI.skin.scrollView.onHover.background = scrollviewhovered;
            GUI.skin.scrollView.onActive.background = scrollviewactive;
            GUI.skin.scrollView.normal.background = scrollview;
            GUI.skin.scrollView.hover.background = scrollviewhovered;
            GUI.skin.scrollView.active.background = scrollviewactive;
        }

        private static Texture2D box = new Texture2D(1, 1);
        public static void Init()
        {
            // button
            button.SetPixel(0, 0, new Color32(55, 55, 55, 255));
            button.Apply();
            buttonhovered.SetPixel(0, 0, new Color32(75, 75, 75, 255));
            buttonhovered.Apply();
            buttonactive.SetPixel(0, 0, new Color32(100, 100, 100, 255));
            buttonactive.Apply();

            // window
            windowbackground.SetPixel(0, 0, new Color32(23, 23, 23, 255));
            windowbackground.Apply();

            // text field & text area
            textarea.SetPixel(0, 0, new Color32(23, 23, 23, 255));
            textarea.Apply();
            textareahovered.SetPixel(0, 0, new Color32(23, 23, 23, 255));
            textareahovered.Apply();
            textareaactive.SetPixel(0, 0, new Color32(43, 43, 43, 255));
            textareaactive.Apply();

            // box
            box.SetPixel(0, 0, new Color32(100, 100, 100, 100));
            box.Apply();

            // scroll bar
            scrollview.SetPixel(0, 0, new Color32(55, 55, 55, 255));
            scrollview.Apply();
            scrollviewhovered.SetPixel(0, 0, new Color32(75, 75, 75, 255));
            scrollviewhovered.Apply();
            scrollviewactive.SetPixel(0, 0, new Color32(100, 100, 100, 255));
            scrollviewactive.Apply();


        }
    }
}
