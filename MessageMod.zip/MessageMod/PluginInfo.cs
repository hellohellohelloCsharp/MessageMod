﻿namespace MessageMod
{
    /// <summary>
    /// This class is used to provide information about your mod to BepInEx.
    /// </summary>
    internal class PluginInfo
    {
        public const string GUID = "com.frost.gorillatag.messagemod";
        public const string Name = "MessageMod";
        public const string Version = "1.0.0";
    }
}
